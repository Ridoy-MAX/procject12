---
name: Questions / Help
about: If you have questions, please read full readme first
title: ''
labels: question
assignees: ''

---

## 💬 Questions and Help

Please before asking your question:

- Read carefully the README of the project
- Search if your answer has already been answered in old issues

After you can submit your question and we will be happy to help you!
