import MutationObserver from 'mutation-observer';

window.MutationObserver = MutationObserver;
