module.exports = {
  trailingComma: 'all',
  printWidth: 100,
  singleQuote: true,
};
